library(testthat)
library(Hapi)

test_check("Hapi")
