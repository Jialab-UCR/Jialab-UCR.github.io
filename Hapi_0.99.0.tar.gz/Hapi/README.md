# *Hapi* - an R/Bioconductor package for chromosome-length haplotype inference using genotypic data of single gamete cells


# Introduction

The knowledge of **complete** rather than fragmental **haplotypes** is **critical in many areas of genetics studies and will advance personalized medicine** including imputation of low-frequent variants, characterization of variant-disease associations, prediction of the clinical outcomes in tranplantation, drug response, and susceptibility to diseases, etc.

Population-based computational phasing methods cannot infer high-resolution haplotypes at chromosome-length and are not able to phase de novo mutations and rare variants, whereas existing experimental phasing methods usually require specialized equipment to separate single chromosomes, which is time-consuming and expensive. Whole-chromosome haplotype phasing with single diploid cells, either require a large number of sequencing libraries or need the assistance of long-read sequencing technologies to phase dense haplotypes at high accuracy thus makes it infeasible for large-scale applications. Using an individual’s genomic data of **single haploid gamete cells** provides a promising approach to overcome limitations in other methods for **chromosome-length haplotype phasing**.

`Hapi` a novel easy-to-use and high-efficient algorithm that only requires **3 to 5 gametes** to reconstruct accurate and high-resolution haplotypes of an individual. The gamete genotype data may be generated from **various platforms including genotyping arrays and sequencing even with low-coverage**. `Hapi` simply takes genotype data of known hetSNPs in single gamete cells as input and report the high-resolution haplotypes as well as confidence of each phased hetSNPs. The package also includes a module allowing **downstream analyses and visualization of identified crossovers** in the gametes. 


# Manual
The comprehensive manual of `Hapi` is available here: [Hapi Manual](http://htmlpreview.github.io/?https://github.com/Jialab-UCR/Jialab-UCR.github.io/blob/master/Hapi_manual.html)


# Installation
`Hapi` is now under review in Bioconductor. Users can install the package locally.

## On Windows system
* Download the package [Hapi_0.99.0.tar.gz](https://github.com/Jialab-UCR/Jialab-UCR.github.io/blob/master/Hapi_0.99.0.tar.gz)
* Make sure you have [Rtools](https://cran.r-project.org/bin/windows/Rtools/) installed
* Add R and Rtools to the Path Variable on the Environment Variables panel, including

  c:\program files\Rtools\bin

  c:\program files\Rtools\gcc-4.6.3\bin

  c:\program files\R\R.3.x.x\bin\i386

  c:\program files\R\R.3.x.x\bin\x64 

* Open a command prompt. Type R CMD INSTALL GDCRNATools_0.99.5.tar.gz

## On Linux and Mac systems
Run the following command in R
```R
install.packages('Hapi_0.99.0.tar.gz', repos = NULL, type='source')
```


