library(testthat)
library(GDCRNATools)

test_check("GDCRNATools")
