## ----installation3, eval=FALSE, message=FALSE, warning=FALSE-------------
#  source("https://bioconductor.org/biocLite.R")
#  biocLite("GDCRNATools")

## ----load, eval=TRUE, message=FALSE, warning=FALSE-----------------------
library(GDCRNATools)

## ----load data q, message=FALSE, warning=FALSE, eval=TRUE----------------
library(DT)

### load RNA counts data
data(rnaCounts)

### load miRNAs counts data
data(mirCounts)

## ----normalization q, message=FALSE, warning=FALSE, eval=TRUE------------
####### Normalization of RNAseq data #######
rnaExpr <- gdcVoomNormalization(counts = rnaCounts, filter = FALSE)

####### Normalization of miRNAs data #######
mirExpr <- gdcVoomNormalization(counts = mirCounts, filter = FALSE)

## ----parse meta2 q, message=FALSE, warning=FALSE, eval=TRUE--------------
####### Parse and filter RNAseq metadata #######
metaMatrix.RNA <- gdcParseMetadata(project.id = 'TCGA-CHOL',
                                   data.type  = 'RNAseq', 
                                   write.meta = FALSE)

metaMatrix.RNA <- gdcFilterDuplicate(metaMatrix.RNA)
metaMatrix.RNA <- gdcFilterSampleType(metaMatrix.RNA)
metaMatrix.RNA[1:5,]


## ----deg q, message=FALSE, warning=FALSE, eval=TRUE----------------------
DEGAll <- gdcDEAnalysis(counts     = rnaCounts, 
                        group      = metaMatrix.RNA$sample_type, 
                        comparison = 'PrimaryTumor-SolidTissueNormal', 
                        method     = 'limma')
DEGAll[1:5,]

### All DEGs
deALL <- gdcDEReport(deg = DEGAll, gene.type = 'all')

### DE long-noncoding
deLNC <- gdcDEReport(deg = DEGAll, gene.type = 'long_non_coding')

### DE protein coding genes
dePC <- gdcDEReport(deg = DEGAll, gene.type = 'protein_coding')

## ----ce q, message=TRUE, warning=FALSE, eval=TRUE------------------------
ceOutput <- gdcCEAnalysis(lnc         = rownames(deLNC), 
                          pc          = rownames(dePC), 
                          lnc.targets = 'starBase', 
                          pc.targets  = 'starBase', 
                          rna.expr    = rnaExpr, 
                          mir.expr    = mirExpr)

ceOutput[1:5,]

## ----sig q, message=FALSE, warning=FALSE, eval=TRUE----------------------
ceOutput2 <- ceOutput[ceOutput$hyperPValue<0.01 
    & ceOutput$corPValue<0.01 & ceOutput$regSim != 0,]

## ----edges q, message=FALSE, warning=FALSE, eval=TRUE--------------------
### Export edges
edges <- gdcExportNetwork(ceNetwork = ceOutput2, net = 'edges')
edges[1:5,]


## ----nodes q, message=FALSE, warning=FALSE, eval=TRUE--------------------
### Export nodes
nodes <- gdcExportNetwork(ceNetwork = ceOutput2, net = 'nodes')
nodes[1:5,]

## ----manual, eval=FALSE, message=FALSE, warning=FALSE--------------------
#  project <- 'TCGA-CHOL'
#  rnadir <- paste(project, 'RNAseq', sep='/')
#  mirdir <- paste(project, 'miRNAs', sep='/')
#  
#  ####### Download RNAseq data #######
#  gdcRNADownload(project.id     = 'TCGA-CHOL',
#                 data.type      = 'RNAseq',
#                 write.manifest = FALSE,
#                 directory      = rnadir)
#  
#  ####### Download miRNAs data #######
#  gdcRNADownload(project.id     = 'TCGA-CHOL',
#                 data.type      = 'miRNAs',
#                 write.manifest = FALSE,
#                 directory      = mirdir)
#  

## ----parse meta2, message=FALSE, warning=FALSE, eval=TRUE----------------
####### Parse RNAseq metadata #######
metaMatrix.RNA <- gdcParseMetadata(project.id = 'TCGA-CHOL',
                                   data.type  = 'RNAseq', 
                                   write.meta = FALSE)

####### Filter duplicated samples in RNAseq metadata #######
metaMatrix.RNA <- gdcFilterDuplicate(metaMatrix.RNA)

####### Filter non-Primary Tumor and non-Solid Tissue Normal samples in RNAseq metadata #######
metaMatrix.RNA <- gdcFilterSampleType(metaMatrix.RNA)

## ----parse meta3, message=FALSE, warning=FALSE, eval=TRUE----------------
####### Parse miRNAs metadata #######
metaMatrix.MIR <- gdcParseMetadata(project.id = 'TCGA-CHOL',
                                   data.type  = 'miRNAs', 
                                   write.meta = FALSE)

####### Filter duplicated samples in miRNAs metadata #######
metaMatrix.MIR <- gdcFilterDuplicate(metaMatrix.MIR)

####### Filter non-Primary Tumor and non-Solid Tissue Normal samples in miRNAs metadata #######
metaMatrix.MIR <- gdcFilterSampleType(metaMatrix.MIR)

## ----merge RNAseq, message=FALSE, warning=FALSE, eval=FALSE--------------
#  ####### Merge RNAseq data #######
#  rnaCounts <- gdcRNAMerge(metadata  = metaMatrix.RNA,
#                           path      = rnadir,
#                           data.type = 'RNAseq')
#  
#  ####### Merge miRNAs data #######
#  mirCounts <- gdcRNAMerge(metadata  = metaMatrix.MIR,
#                           path      = mirdir,
#                           data.type = 'miRNAs')

## ----normalization, message=FALSE, warning=FALSE, eval=FALSE-------------
#  ####### Normalization of RNAseq data #######
#  rnaExpr <- gdcVoomNormalization(counts = rnaCounts, filter = FALSE)
#  
#  ####### Normalization of miRNAs data #######
#  mirExpr <- gdcVoomNormalization(counts = mirCounts, filter = FALSE)

## ----deg, message=FALSE, warning=FALSE, eval=FALSE-----------------------
#  DEGAll <- gdcDEAnalysis(counts     = rnaCounts,
#                          group      = metaMatrix.RNA$sample_type,
#                          comparison = 'PrimaryTumor-SolidTissueNormal',
#                          method     = 'limma')

## ----data, message=FALSE, warning=FALSE, eval=TRUE-----------------------
data(DEGAll)

## ----extract, message=FALSE, warning=FALSE, eval=TRUE--------------------
### All DEGs
deALL <- gdcDEReport(deg = DEGAll, gene.type = 'all')

### DE long-noncoding
deLNC <- gdcDEReport(deg = DEGAll, gene.type = 'long_non_coding')

### DE protein coding genes
dePC <- gdcDEReport(deg = DEGAll, gene.type = 'protein_coding')

## ----ce, message=FALSE, warning=FALSE, eval=FALSE------------------------
#  ceOutput <- gdcCEAnalysis(lnc         = rownames(deLNC),
#                            pc          = rownames(dePC),
#                            lnc.targets = 'starBase',
#                            pc.targets  = 'starBase',
#                            rna.expr    = rnaExpr,
#                            mir.expr    = mirExpr)

## ----ce 2, message=FALSE, warning=FALSE, eval=TRUE-----------------------
### load miRNA-lncRNA interactions
data(lncTarget)

### load miRNA-mRNA interactions
data(pcTarget)
pcTarget[1:3]

## ----ce 22, message=FALSE, warning=FALSE, eval=FALSE---------------------
#  ceOutput <- gdcCEAnalysis(lnc         = rownames(deLNC),
#                            pc          = rownames(dePC),
#                            lnc.targets = lncTarget,
#                            pc.targets  = pcTarget,
#                            rna.expr    = rnaExpr,
#                            mir.expr    = mirExpr)

## ----message=FALSE, warning=FALSE, eval=FALSE----------------------------
#  ceOutput2 <- ceOutput[ceOutput$hyperPValue<0.01 &
#      ceOutput$corPValue<0.01 & ceOutput$regSim != 0,]
#  
#  edges <- gdcExportNetwork(ceNetwork = ceOutput2, net = 'edges')
#  nodes <- gdcExportNetwork(ceNetwork = ceOutput2, net = 'nodes')
#  
#  write.table(edges, file='edges.txt', sep='\t', quote=F)
#  write.table(nodes, file='nodes.txt', sep='\t', quote=F)

## ----shiny cor plot, eval=FALSE, echo=TRUE, message=FALSE, warning=FALSE----
#  shinyCorPlot(gene1    = rownames(deLNC),
#               gene2    = rownames(dePC),
#               rna.expr = rnaExpr,
#               metadata = metaMatrix.RNA)

## ----survival, message=FALSE, warning=FALSE, eval=FALSE------------------
#  ####### CoxPH analysis #######
#  survOutput <- gdcSurvivalAnalysis(gene     = rownames(deALL),
#                                    method   = 'coxph',
#                                    rna.expr = rnaExpr,
#                                    metadata = metaMatrix.RNA)

## ----survival2, message=FALSE, warning=FALSE, eval=FALSE-----------------
#  ####### KM analysis #######
#  survOutput <- gdcSurvivalAnalysis(gene     = rownames(deALL),
#                                    method   = 'KM',
#                                    rna.expr = rnaExpr,
#                                    metadata = metaMatrix.RNA,
#                                    sep      = 'median')

## ----shiny km plot, eval=FALSE, echo=TRUE, message=FALSE, warning=FALSE, eval=FALSE----
#  shinyKMPlot(gene = rownames(deALL), rna.expr = rnaExpr,
#              metadata = metaMatrix.RNA)

## ----enrichment, message=FALSE, warning=FALSE, eval=FALSE----------------
#  enrichOutput <- gdcEnrichAnalysis(gene = rownames(deALL), simplify = TRUE)

## ----enrichment data, message=FALSE, warning=FALSE, eval=TRUE------------
data(enrichOutput)

## ----go bar, fig.height=8, fig.width=15.5, message=FALSE, warning=FALSE, eval=TRUE----
gdcEnrichPlot(enrichOutput, type = 'bar', category = 'GO', num.terms = 10)

## ----go bubble, echo=TRUE, fig.height=8, fig.width=12.5, message=FALSE, warning=FALSE, eval=TRUE----
gdcEnrichPlot(enrichOutput, type='bubble', category='GO', num.terms = 10)

## ----shiny pathview, message=FALSE, warning=FALSE, eval=FALSE------------
#  library(pathview)
#  
#  deg <- deALL$logFC
#  names(deg) <- rownames(deALL)
#  pathways <- as.character(enrichOutput$Terms[enrichOutput$Category=='KEGG'])

## ----shiny pathview2, eval=FALSE, echo=TRUE, message=FALSE, warning=FALSE----
#  shinyPathview(deg, pathways = pathways, directory = 'pathview')

## ----sessionInfo---------------------------------------------------------
sessionInfo()

